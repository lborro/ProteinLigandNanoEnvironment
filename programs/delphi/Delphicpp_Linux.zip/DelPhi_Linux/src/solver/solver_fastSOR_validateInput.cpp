/*
 * solver_fastSOR_validateInput.cpp
 *
 *  Created on: Feb 16, 2014
 *      Author: chuan
 */

#include "solver_fastSOR.h"

void CDelphiFastSOR::validateInput()
{

}
