#include "space.h"

void CDelphiSpace::validateInput()
{
   //if (bCrgInterplateType) CSphericalCrgIntelp waring();
    cout << "validate input in space module...." << endl;
    if(space_debug) cout << "############### cleanMem in Space module.... ##################" << endl;


    //free_pt3d <bool> (idebmap,iGrid,iGrid,iGrid);

    //if(iepsmp != NULL) free_index_3d <SGrid <delphi_integer> > (iepsmp,iGrid,iGrid,iGrid);


}

