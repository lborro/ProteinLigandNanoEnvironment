/*
 * exceptions.cpp
 *
 *  Created on: July 02, 2013
 *      Author: chuan
 */

#include "exceptions.h"

/*
 * Declaring a static member variable is not enough, you need to also define it somewhere.
 * This should be in a .cpp file that includes the header (.h) file that declared them.
 */

int CWarning::iWarningNum = 0;


